import React from 'react';
import ItemImg from './ItemImg';
import TextBig from './TextBig';


export default function Galery(){
    return(
        <div className="one-column content">
           <img src="../public/foto1.png" alt="" />
           <img src="../public/foto2.png" alt="" />
           <img src="../public/foto3.png" alt="" />
        
            <div className="inner-container">
            <img src="../public/foto4.png" alt="" />
           <img src="../public/foto5.png" alt="" />
           <img src="../public/foto6.png" alt="" />
                </div>
        </div>
    )
}