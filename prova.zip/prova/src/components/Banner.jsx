import React from 'react';
import TextBig from './TextBig';
import Button from './Button';


export default function Banner(){
    return(
        <div className='banner container'>
            <div className="two-column content">
                <div className="inner-content">
                    <TextBig label="Clube do Livro"/>
                    <p>SESI</p>
                    <h5>Desvende novos universos literários, explore diferentes perspectivas e faça amigos em um ambiente acolhedor e convidativo.</h5>
                <h6>Data:06/05    Horario:18:00 </h6>
                <h8>Escola Sesi</h8>
                </div>
            </div>
            <div className="two-column content">
                <img src="../public/primeira.jpg" alt="" />
            </div>
        </div>
    )
}